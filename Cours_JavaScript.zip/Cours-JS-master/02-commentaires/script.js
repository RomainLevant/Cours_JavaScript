// Ceci est un commentaire

/* 
commentaire
multi 
lignes
*/

/**
 * Commentaire de documentation
 * 
 * Return the string "Hello $name"
 * @param string name 
 * @return string
 */
function sayHello(name)
{
    return "Hello "+name;
}