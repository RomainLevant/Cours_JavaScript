// - Créer une variable et y stocker une chaine
var firstname = "Bruce";

// - Créer une variable et y stocker un nombre (entier ou decimal)
var age = 80;

// - Créer un tableau, lui ajouter en index 0 la variable contenant le nombre et en index 1 la variable contenant la chaine
var user = [age, firstname];

// console.log("Age de "+ user[1]+" est "+user[0]);


// - Afficher le tableau dans la console
console.log(user);

// - Afficher l'index 1 du tableau dans la console
console.log(user[1]);