// Ceci est un script externe
alert("GoodBye World");