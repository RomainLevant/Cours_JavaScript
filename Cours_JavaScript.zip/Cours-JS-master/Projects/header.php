<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Projet</title>

    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    
    <header id="main-header" class="main-header">

        <nav>
            <a href="index.php">INDEX</a>
            <a href="b.php">Page B</a>
            <a href="c.php">Page C</a>
            <a href="d.php">Page D</a>
            <a href="e.php">Page E</a>
        </nav>

    </header><!-- End .main-header -->

    <div id="main-content" class="main-content">
