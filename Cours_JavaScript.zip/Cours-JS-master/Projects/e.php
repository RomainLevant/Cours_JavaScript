<?php include("header.php"); ?>
<!-- ======================================================================= -->

        <h1>Page E</h1>

        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates ex, mollitia sint cupiditate dolores voluptatum ratione doloremque deserunt officiis sapiente iusto, modi ad voluptas libero eum vel! Nostrum, dolore! Facere?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates ex, mollitia sint cupiditate dolores voluptatum ratione doloremque deserunt officiis sapiente iusto, modi ad voluptas libero eum vel! Nostrum, dolore! Facere?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates ex, mollitia sint cupiditate dolores voluptatum ratione doloremque deserunt officiis sapiente iusto, modi ad voluptas libero eum vel! Nostrum, dolore! Facere?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates ex, mollitia sint cupiditate dolores voluptatum ratione doloremque deserunt officiis sapiente iusto, modi ad voluptas libero eum vel! Nostrum, dolore! Facere?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates ex, mollitia sint cupiditate dolores voluptatum ratione doloremque deserunt officiis sapiente iusto, modi ad voluptas libero eum vel! Nostrum, dolore! Facere?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates ex, mollitia sint cupiditate dolores voluptatum ratione doloremque deserunt officiis sapiente iusto, modi ad voluptas libero eum vel! Nostrum, dolore! Facere?</p>

<!-- ======================================================================= -->
<?php include("footer.php"); ?>
