
    </div><!-- End .main-content -->

<footer id="main-footer" class="main-footer">

    <!-- Footer Nav -->
    <div class="footer-nav">

        <nav>
            <a href="a.php">Page A</a>
            <a href="b.php">Page B</a>
            <a href="c.php">Page C</a>
            <a href="d.php">Page D</a>
        </nav>

    </div><!-- End .footer-nav -->

    <!-- Footer Legal -->
    <div class="footer-legal">
        &copy; 2020 My Awesome Website
    </div><!-- End .footer-legal -->

</footer><!-- End .main-footer -->

<script src="assets/js/script.js"></script>
</body>
</html>